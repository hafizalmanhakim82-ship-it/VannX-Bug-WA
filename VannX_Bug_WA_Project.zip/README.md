# VannX Bug WA — Android project

Aplikasi Android edukasi berupa simulator lokal bertema dark-neon. Semua skenario berjalan di dalam aplikasi VannX sendiri. Aplikasi ini tidak mengirim payload, spam, pesan, atau trafik ke WhatsApp maupun perangkat lain.

## Membuka proyek
1. Unduh dan ekstrak `VannX_Bug_WA_Project.zip`.
2. Instal Android Studio versi terbaru.
3. Pilih **Open** lalu pilih folder `VannX_Bug_WA`.
4. Tunggu Gradle Sync selesai. Jika diminta, instal Android SDK Platform 35.
5. Hubungkan HP Android dengan USB debugging aktif, atau pilih emulator.
6. Tekan tombol **Run** untuk memasang aplikasi.

## Membuat APK
Di Android Studio: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
APK debug biasanya tersedia di:
`app/build/outputs/apk/debug/app-debug.apk`

## Catatan
- Package: `com.vannx.bugwa`
- Nama aplikasi: `VannX Bug WA`
- Minimum Android: Android 6.0 (API 23)
- Target SDK: 35
- Untuk rilis publik, buat signing key sendiri melalui **Build > Generate Signed Bundle / APK**.
