package com.vannx.bugwa

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF080B14)
private val Panel = Color(0xFF121827)
private val Cyan = Color(0xFF35D9FF)
private val Purple = Color(0xFF9B7BFF)
private val Muted = Color(0xFF9AA7BD)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VannXApp() }
    }
}

@Composable
fun VannXApp() {
    var selected by remember { mutableStateOf("Simulasi") }
    var running by remember { mutableStateOf(false) }
    var rounds by remember { mutableIntStateOf(0) }
    var log by remember { mutableStateOf("Sistem siap. Pilih simulasi untuk memulai.") }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg, surface = Panel, primary = Cyan,
            secondary = Purple, onBackground = Color.White, onSurface = Color.White
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(horizontal = 18.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                contentPadding = PaddingValues(top = 28.dp, bottom = 28.dp)
            ) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(48.dp).background(
                                Brush.linearGradient(listOf(Cyan, Purple)),
                                RoundedCornerShape(15.dp)
                            ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.BugReport, null, tint = Bg, modifier = Modifier.size(29.dp))
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("VannX", fontSize = 25.sp, fontWeight = FontWeight.Black)
                            Text("BUG WA • SAFE SIMULATOR", color = Cyan, fontSize = 10.sp, letterSpacing = 2.sp)
                        }
                        Surface(color = Color(0xFF16352F), shape = RoundedCornerShape(30.dp)) {
                            Text("● ONLINE", Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                color = Color(0xFF66E6B0), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                item {
                    Box(
                        Modifier.fillMaxWidth().background(
                            Brush.linearGradient(listOf(Color(0xFF17283B), Color(0xFF241A3A))),
                            RoundedCornerShape(22.dp)
                        ).padding(20.dp)
                    ) {
                        Column {
                            Text("CONTROL CENTER", color = Cyan, fontSize = 11.sp, letterSpacing = 2.sp)
                            Spacer(Modifier.height(8.dp))
                            Text("Uji. Amati. Pelajari.", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(5.dp))
                            Text("Simulasi lokal untuk memahami perilaku aplikasi tanpa mengirim gangguan ke WhatsApp atau perangkat lain.",
                                color = Muted, fontSize = 13.sp, lineHeight = 19.sp)
                        }
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        StatCard("MODE", "SIM", Icons.Default.Terminal, Modifier.weight(1f))
                        StatCard("TEST", rounds.toString(), Icons.Default.History, Modifier.weight(1f))
                        StatCard("SAFETY", "LOCAL", Icons.Default.Security, Modifier.weight(1f))
                    }
                }
                item {
                    Text("PILIH MODUL", color = Muted, fontSize = 11.sp, letterSpacing = 2.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Simulasi", "Performa", "Log").forEach { item ->
                            FilterChip(
                                selected = selected == item,
                                onClick = { selected = item },
                                label = { Text(item) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Color(0xFF153748),
                                    selectedLabelColor = Cyan
                                )
                            )
                        }
                    }
                }
                item {
                    when (selected) {
                        "Simulasi" -> {
                            ModuleCard("Simulasi respons", "Menjalankan skenario dummy di dalam aplikasi ini saja.") {
                                Button(
                                    onClick = {
                                        running = !running
                                        if (running) {
                                            rounds++
                                            log = "[$rounds] Simulasi lokal selesai: respons dummy NORMAL. Tidak ada pesan atau trafik WhatsApp yang dikirim."
                                        } else {
                                            log = "Simulasi dihentikan."
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Bg)
                                ) { Text(if (running) "HENTIKAN SIMULASI" else "JALANKAN SIMULASI", fontWeight = FontWeight.Bold) }
                            }
                        }
                        "Performa" -> {
                            ModuleCard("Pemeriksaan UI lokal", "Cek interaksi tombol dan tampilan aplikasi VannX tanpa mengakses WhatsApp.") {
                                Button(onClick = {
                                    rounds++
                                    log = "[$rounds] Pemeriksaan UI lokal berhasil. Tidak ditemukan aksi eksternal."
                                }, modifier = Modifier.fillMaxWidth()) { Text("JALANKAN CEK UI") }
                            }
                        }
                        else -> {
                            ModuleCard("Riwayat aktivitas", "Catatan simulasi terakhir pada perangkat ini.") {
                                Text(log, color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
                            }
                        }
                    }
                }
                item {
                    Column(
                        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(16.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Terminal, null, tint = Cyan)
                            Spacer(Modifier.width(8.dp))
                            Text("OUTPUT CONSOLE", fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 1.sp)
                        }
                        Spacer(Modifier.height(12.dp))
                        Text("> $log", color = Color(0xFF9CEBD8), fontSize = 12.sp, lineHeight = 18.sp)
                    }
                }
                item {
                    Text("VannX Bug WA adalah simulator edukasi. Aplikasi ini tidak mengeksploitasi WhatsApp, tidak mengirim spam, dan tidak membuat perangkat lain crash.",
                        color = Muted, fontSize = 10.sp, lineHeight = 15.sp)
                }
            }
        }
    }
}

@Composable
private fun StatCard(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier) {
    Column(modifier.background(Panel, RoundedCornerShape(16.dp)).padding(12.dp)) {
        Icon(icon, null, tint = Cyan, modifier = Modifier.size(18.dp))
        Spacer(Modifier.height(10.dp))
        Text(value, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        Text(title, fontSize = 9.sp, color = Muted, letterSpacing = 1.sp)
    }
}

@Composable
private fun ModuleCard(title: String, subtitle: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(title, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Text(subtitle, color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
        content()
    }
}
